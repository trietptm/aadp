------------------------------------------------------------------------------------
aadp4immdbg - Anti-Anti-Debugger Plugin for ImmunityDebugger v0.2.1

Coded by: +NCR/CRC! [ReVeRsEr] - CracksLatinoS! 2010
Buenos Aires, Argentina - November / 2010
------------------------------------------------------------------------------------

-- [ Introduction ] --

aadp4immdbg is a plugin for ImmunityDebugger that aims to hide ImmDbg from most of the common anti-debugger tricks.

Use it at your own risk!

-- [ What's in aadp4immdbg v0.2.1? ] --

In this version, many anti-antidbg tricks were added to hide your ImmDbg from the following tricks:

 * BlockInput
 * SuspendThread
 * UnhandledExceptionFilter
 * Process32Next
 * Module32Next
 * ZwQuerySystemInformation
 * ZwQueryObject
 * TerminateProcess
 * ZwOPenProcess
 * FindWindow
 
Also, it fully supports XP (ALL), Vista (ALL) and Windows 7 OS.

-- [ Installation ] --

Just copy TitanEngine.dll to the ImmDbg's folder and the aadp4immdbg.dll to your plugin folder and that's all.

-- [ How to use it ] --

Check the tricks you want to activate and restart the program you want to work with.

-- [ Supported Platforms ] --

aadp4immdbg was tested in the following platforms using ImmunityDebugger v1.73:

* Windows XP Professional SP0 (English)
* Windows XP Professional SP2 (English)
* Windows XP Professional SP3 (English)
* Windows XP Professional SP3 (Spanish)
* Windows Vista Home Basic SP2 (English)
* Windows Vista Home Premium SP2 (English)
* Windows Vista Ultimate SP2 (English)
* Windows 7 Ultimate SP0 (English)

-- [ Credits and thanks ] --

This tool uses the TitanEngine SDK from ReversingLabs:

- http://www.reversinglabs.com/products/TitanEngine.php

i would like to say thanks to the people who helped me with first version, thanks to:

 * marciano for being my official beta tester in all my projects, thanks panchote!.
 * LCF-AT for reporting bugs and ideas for next releases.
 * Peter Ferrier for pointing me errors in the funcion's hooks (i'll fix it for v0.3!).
 * ahmadmansoor for ideas for next releases.
 * chessgod101 for pointing me the OutputDebugStringW antidbg trick.
 * zugo for being my official GFX artits.
 * SunBeam for pointing me some antidbg tricks.
 * Fungus for pointing me some antidbg tricks.
 
Also, thanks to all the people in ARTeam, tuts4you, Black Storm Reversing, Woodman and exetools for supporting me!!!.

-- [ License ]

aadp4immdbg is distributed under the GPL v3 license. 

Please, read the LICENSE file.

-- [ Bugs, Suggestions, Comments, Features, Whatever ]

aadp Homepage: http://code.google.com/p/aadp/

My personal email: nahuelriva@gmail.com

You can find me in:

- http://crackinglandia.blogspot.com
- http://twitter.com/crackinglandia

see you in the next release! :)

+NCR/CRC! [ReVeRsEr]