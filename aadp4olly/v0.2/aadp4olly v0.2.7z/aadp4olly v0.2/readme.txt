------------------------------------------------------------------------------------
aadp4olly - Anti-Anti-Debugger Plugin for Olly v0.2

Coded by: +NCR/CRC! [ReVeRsEr] - CracksLatinoS! 2010
Buenos Aires, Argentina - November / 2010
------------------------------------------------------------------------------------

-- [ Introduction ] --

aadp4olly is a plugin for Ollydbg that aims to hide Ollydbg from most of the common anti-debugger tricks.

Use it at your own risk!

-- [ What's new in aadp4olly v0.2? ] --

In this new version, many anti-antidbg tricks were added to hide your Ollydbg from the following tricks:

 * BlockInput
 * SuspendThread
 * UnhandledExceptionFilter
 * Process32Next
 * Module32Next
 * ZwQuerySystemInformation
 * ZwQueryObject
 * TerminateProcess
 * ZwOPenProcess
 * FindWindow
 
Also, some code refactoring in order to fully support XP (ALL), Vista (ALL) and Windows 7 OS.

-- [ Installation ] --

Just copy TitanEngine.dll to the Ollydbg's folder and the aadp4olly.dll to your plugin folder and that's all.

-- [ How to use it ] --

Check the tricks you want to activate and restart the program you want to work with.

-- [ Supported Platforms ] --

aadp4olly was tested in the following platforms using Ollydbg v1.10:

* Windows XP Professional SP0 (English)
* Windows XP Professional SP2 (English)
* Windows XP Professional SP3 (English)
* Windows XP Professional SP3 (Spanish)
* Windows Vista Home Basic SP2 (English)
* Windows Vista Home Premium SP2 (English)
* Windows Vista Ultimate SP2 (English)
* Windows 7 Ultimate SP0 (English)

-- [ Credits and thanks ] --

This tool uses the TitanEngine SDK from ReversingLabs:

- http://www.reversinglabs.com/products/TitanEngine.php

i would like to say thanks to the people who helped me with first version, thanks to:

 * marciano for being my official beta tester in all my projects, thanks panchote!.
 * LCF-AT for reporting bugs and ideas for next releases.
 * Peter Ferrier for pointing me errors in the funcion's hooks (i'll fix it for v0.3!).
 * ahmadmansoor for ideas for next releases.
 * chessgod101 for pointing me the OutputDebugStringW antidbg trick.
 * zugo for being my official GFX artits.
 * SunBeam for pointing me some antidbg tricks.
 * Fungus for pointing me some antidbg tricks.
 
Also, thanks to all the people in ARTeam, tuts4you, Black Storm Reversing, Woodman and exetools for supporting me!!!.

-- [ License ]

aadp4olly is distributed under the GPL v3 license. 

Please, read the LICENSE file.

-- [ Bugs, Suggestions, Comments, Features, Whatever ]

aadp Homepage: http://code.google.com/p/aadp/

My personal email: nahuelriva@gmail.com

You can find me in:

- http://crackinglandia.blogspot.com
- http://twitter.com/crackinglandia

see you in the next release! :)

+NCR/CRC! [ReVeRsEr]